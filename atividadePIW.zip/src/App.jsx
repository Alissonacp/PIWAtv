import { useEffect, useState } from 'react';
import { filmes } from './data/movies';
import MovieList from './components/movieList';
import FavoriteMessage from './components/favoriteMessage';
import './App.css';

function App() {
  const [favoritos, setFavoritos] = useState([]);

  const toggleFavorito = (id) => {
    setFavoritos((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  useEffect(() => {
    console.log('Favoritos:', favoritos);
  }, [favoritos]);

  return (
    <div className="App">
      <h1>Minha Lista de Filmes</h1>

      <h2>Seus Filmes Favoritos:</h2>
      <FavoriteMessage total={favoritos.length} />

      <h2>Filmes Disponíveis:</h2>
      <MovieList
        filmes={filmes}
        favoritos={favoritos}
        toggleFavorito={toggleFavorito}
      />
    </div>
  );
}

export default App;
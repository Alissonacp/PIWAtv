function MovieList({ filmes, favoritos, toggleFavorito }) {
    return (
        <div className="movie-list">
            {filmes.map((filme) => (
                <div key={filme.id} className="movie-card">
                    <div className="movie-info">
                        <h3>{filme.title}</h3>
                        <p>{filme.description}</p>
                    </div>
                    <button
                        className={favoritos.includes(filme.id) ? 'desfavoritar' : 'favoritar'}
                        onClick={() => toggleFavorito(filme.id)}
                    >
                        {favoritos.includes(filme.id) ? 'Desfavoritar' : 'Favoritar'}
                    </button>
                </div>
            ))}
        </div>
    );
}

export default MovieList;
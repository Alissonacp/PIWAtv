function FavoriteMessage({ total }) {
  let msg = '';

  if (total === 0) msg = 'Você ainda não favoritou nenhum filme.';
  else if (total <= 2) msg = 'Você tem alguns filmes favoritos!';
  else msg = 'Uau! Uma coleção impressionante de favoritos!';

  return <p className="message">{msg}</p>;
}

export default FavoriteMessage;

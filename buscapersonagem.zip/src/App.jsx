import { useState,useEffect } from 'react'
import './App.css'

function App() {
  const [personagens, setPersonagens] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const url = `https://rickandmortyapi.com/api/character/?name=${searchTerm}`;
  useEffect(() => {
    const fetchPersonagens = async () => {
      url
      try {
        const response = await fetch(url);
        if (!response.ok) {
          if(response.status === 404) {
            setPersonagens([]);            
          }
          else {
            throw new Error(`Erro HTTP: ${response.status}`);
          }
        }else {
          const data = await response.json();
          setPersonagens(data.results || []);          
        }
      
      } catch (err) {
        console.error('error ao buscar personagem: ',err);
        
      } 
    }
    fetchPersonagens();

  },[searchTerm]);
  return (
    <>
      <div className='container'>
        <h1>
          Lista de personagens rick and morty
        </h1>
        <input         
        type="text"
        className='search-input'
        placeholder='perquise por nome'
        value={searchTerm} onChange={e => setSearchTerm(e.target.value)}

         />
         <div className='character-grid'>
            {personagens.map(personagem  => (
              <div key={personagem.id} className='character-card'>
                <img src={personagem.image} alt={personagem.name}/>
                <h3>{personagem.name}</h3>
               <p> Especie: {personagem.species}</p>
               <p>Status: {personagem.status}</p>
              </div>              
            ))}
          </div>
      

      </div>
    </>
  )
}

export default App

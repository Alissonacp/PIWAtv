import { use, useEffect, useState } from "react";
import "./App.css";

function App() {
  const pecas = {
    processadores: [
      { id: "p1", nome: "Intel Core i5", preco: 850.0 },
      { id: "p2", nome: "Intel Core i7", preco: 1350.0 },
      { id: "p3", nome: "AMD Ryzen 5", preco: 800.0 },
      { id: "p4", nome: "AMD Ryzen 7", preco: 1250.0 },
    ],
    memoriasRAM: [
      { id: "m1", nome: "8GB DDR4", preco: 250.0 },
      { id: "m2", nome: "16GB DDR4", preco: 450.0 },
      { id: "m3", nome: "32GB DDR4", preco: 900.0 },
    ],
    armazenamentos: [
      { id: "a1", nome: "SSD 240GB", preco: 200.0 },
      { id: "a2", nome: "SSD 480GB", preco: 350.0 },
      { id: "a3", nome: "HD 1TB", preco: 300.0 },
    ],
  };
  const [processadorSelect, setProcessador] = useState(null);
  const [ramSelect, setRAM] = useState(null);
  const [armazenamentoSelect, setArmazenamento] = useState(null);
  const [total, setTotal] = useState(0);
  const [montagemCompleta, setMontagemCompleta] = useState(false);


  useEffect(() => {
    let novoTotal = 0;
    if (processadorSelect != null) {
      novoTotal += processadorSelect.preco;
    }
    if (ramSelect != null) {
      novoTotal += ramSelect.preco;
    }
    if (armazenamentoSelect != null) {
      novoTotal += armazenamentoSelect.preco;
    }
    setTotal(novoTotal);
  }, [ramSelect, processadorSelect, armazenamentoSelect]);

  useEffect(() => {
    if(ramSelect && processadorSelect  && armazenamentoSelect) {
      setMontagemCompleta(true)
    }else {
    setMontagemCompleta(false)
    }
  },[processadorSelect, ramSelect, armazenamentoSelect])
  return (
    <div className="container">
      <h1>Monte seu pc</h1>
      <div className="pecas">
        <p>processador</p>
        <select
          onChange={(e) => {
            const selectedId = e.target.value;
            const selected = pecas.processadores.find(
              (p) => p.id === selectedId
            );
            setProcessador(selected || null);
          }}
        >
          <option value="">--selecione uma opção--</option>
          {pecas.processadores.map((item) => (
            <option key={item.id} value={item.id}>
              {item.nome} - (R$ {item.preco})
            </option>
          ))}
        </select>
        <p>Memoria RAM</p>
        <select
          onChange={(e) => {
            const selectedId = e.target.value;
            const selected = pecas.memoriasRAM.find((p) => p.id === selectedId);
            setRAM(selected || null);
          }}
        >
          <option value="">--selecione uma opção--</option>
          {pecas.memoriasRAM.map((item) => (
            <option key={item.id} value={item.id}>
              {item.nome} - (R$ {item.preco})
            </option>
          ))}
        </select>
        <p>Armazenamento</p>
        <select
          onChange={(e) => {
            const selectedId = e.target.value;
            const selected = pecas.armazenamentos.find(
              (p) => p.id === selectedId
            );
            setArmazenamento(selected || null);
          }}
        >
          <option value="">--selecione uma opção--</option>
          {pecas.armazenamentos.map((item) => (
            <option key={item.id} value={item.id}>
              {item.nome} - (R$ {item.preco})
            </option>
          ))}
        </select>
      </div>
      <div className="resumo-montagem">
        <h3>Resumo da montagem</h3>
        <p>
          Processador:{" "}
          {processadorSelect ? processadorSelect.nome : "nao selecionado"}{" "}
        </p>
        <p>Memoria RAM:{ramSelect ? ramSelect.nome : "nao selecionado"}</p>
        <p>
          Armazenamento:{" "}
          {armazenamentoSelect ? armazenamentoSelect.nome : "nao selecionado"}
        </p>
        <hr />
        <h3>preço total: R$ {total.toFixed(2)}</h3>
      </div>
      <button className={montagemCompleta? 'btn-green' : 'btn-gray'} onClick={ () => {
        alert(`o pc vai custar:  R$: ${total.toFixed(2)} `)

      }
      }>Confirmar Montagem</button>
    </div>
  );
}

export default App;
